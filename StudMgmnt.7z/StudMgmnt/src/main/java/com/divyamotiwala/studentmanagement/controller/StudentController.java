package com.divyamotiwala.studentmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.divyamotiwala.studentmanagement.entity.Student;
import com.divyamotiwala.studentmanagement.service.StudentService;

@Controller
@RequestMapping("/student")	
public class StudentController {
	
	@Autowired
	StudentService studentService;
	
	@RequestMapping("/list")
	public String getAllStudents(Model theModel)
	{
		List<Student> student = studentService.getAllStudents();
		theModel.addAttribute("studentModel", student);
		return "student-list";
	}
	
	@RequestMapping("/add")
	public String showFormForAdd(Model theModel)
	{
		Student student = new Student();
		theModel.addAttribute("student", student);
		return "student-form"; 
	}
	
	@RequestMapping("/update")
	public String showFormForUpdate(@RequestParam("id") int id, Model theModel)
	{
		Student student = studentService.getStudentById(id);
		theModel.addAttribute("student", student);
		return "student-form"; 
	}
	
	@RequestMapping("/delete")
	public String deleteStudent(@RequestParam("id") int id) {
		Student student = studentService.deleteStudent(id);
		System.out.println("Deleted Student Id "+ student.getStudentId());
		return "redirect:/student/list";
	}
	
	@PostMapping("/save")
	public String saveBook(@RequestParam("id") int id, @RequestParam("name") String name,
			@RequestParam("department") String department, @RequestParam("country") String country) {
		Student student;
		if(id != 0) {
			student = studentService.getStudentById(id);
		}else {
			student = new Student();
		}
		student.setStudentName(name);
		student.setStudentDepartment(department);
		student.setStudentCountry(country);
		studentService.addStudent(student);
		return "redirect:/student/list";
	}

}
