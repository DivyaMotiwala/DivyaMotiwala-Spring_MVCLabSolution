package com.divyamotiwala.studentmanagement.service;

import java.util.List;

import com.divyamotiwala.studentmanagement.entity.Student;

public interface StudentService {

	public List<Student> getAllStudents();
	public void addStudent(Student newStudent);
	public Student deleteStudent(int studentId);
	public Student getStudentById(int studentId);
	
}
