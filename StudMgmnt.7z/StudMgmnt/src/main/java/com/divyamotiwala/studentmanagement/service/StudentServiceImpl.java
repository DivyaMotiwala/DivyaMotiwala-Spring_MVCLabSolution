package com.divyamotiwala.studentmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.divyamotiwala.studentmanagement.entity.Student;

@Service
public class StudentServiceImpl implements StudentService {

	SessionFactory sessionFactory;
	Session session;
	
	@Autowired
	public StudentServiceImpl(SessionFactory sessionFactory)
	{
		this.sessionFactory = sessionFactory;
		try
		{
			this.session = sessionFactory.getCurrentSession();
		}catch(HibernateException he)
		{
			this.session = sessionFactory.openSession();
		}
	}
	
	
	@Override
	@Transactional
	public List<Student> getAllStudents() {
		@SuppressWarnings("unchecked")
		List<Student> list = (List<Student>) session.createQuery("from Student").list();
		return list;
	}

	@Override
	@Transactional
	public void addStudent(Student newStudent) {
		session.saveOrUpdate(newStudent);

	}

	@Override
	@Transactional
	public Student deleteStudent(int studentId) {
		Transaction tx = session.getTransaction();
		tx.begin();
		Student student = session.get(Student.class, studentId);
		session.delete(student);
		tx.commit();
		return student;

	}

	@Override
	public Student getStudentById(int studentId) {
		return session.get(Student.class, studentId);

	}

}
